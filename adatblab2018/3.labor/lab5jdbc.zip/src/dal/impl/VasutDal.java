package dal.impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import dal.ActionResult;
import dal.DataAccessLayer;
import dal.exceptions.CouldNotConnectException;
import dal.exceptions.EntityNotFoundException;
import dal.exceptions.NotConnectedException;
import model.JaratFejlec;
import model.Person;
import model.Jarat;
import model.JaratVonatszam;

/**
 * Initial implementation for the DataAccessLayer for the 30-VASUT exercise.
 */
public class VasutDal implements DataAccessLayer<JaratFejlec, Jarat, JaratVonatszam> {
	private Connection connection;
	protected static final String driverName = "oracle.jdbc.driver.OracleDriver";
	protected static final String databaseUrl = "jdbc:oracle:thin:@rapid.eik.bme.hu:1521:szglab";

	private void checkConnected() throws NotConnectedException {
		if (connection == null) {
			throw new NotConnectedException();
		}
	}

	@Override
	public void connect(String username, String password) throws CouldNotConnectException, ClassNotFoundException {
		try {
			if (connection == null || !connection.isValid(30)) {
				if (connection == null) {
					// Load the specified database driver
					Class.forName(driverName);
				} else {
					connection.close();
				}

				// Create new connection and get metadata
				connection = DriverManager.getConnection(databaseUrl, username, password);
			}
		} catch (SQLException e) {
			throw new CouldNotConnectException();
		}
	}

	@Override
	public List<JaratFejlec> search(String keyword) throws NotConnectedException {
		checkConnected();
		
		List<JaratFejlec> jaratok = new ArrayList<>();
		
		try (Statement statement = connection.createStatement()) 
		{
			ResultSet resultSet;
			
			// Ha a kereso mezo ures, kiirjuk az osszes jaratot
			if(keyword.equals(""))
			{
				resultSet = statement.executeQuery("SELECT vonatszam, tipus, megjegyzes FROM jarat ");
				while (resultSet.next()) 
				{
					JaratFejlec jarat = new JaratFejlec();
					jarat.setVonatszam(resultSet.getInt("vonatszam"));
					jarat.setTipus(resultSet.getString("tipus"));
					jarat.setMegjegyzes(resultSet.getString("megjegyzes"));
					
					jaratok.add(jarat);
				}
			}
			else {
				// Ha van benne valamilyen ertek, preparedStatement-el kikeressuk az elemeket
				PreparedStatement preparedStatement = connection.prepareStatement("SELECT vonatszam, tipus, megjegyzes FROM jarat WHERE vonatszam LIKE ? ESCAPE '@'");
				// Beallitjuk a feltetelt				
				preparedStatement.setString(1, keyword);
				// Vegrehajtjuk a lekerdezest
				resultSet = preparedStatement.executeQuery();
				// Az eredmenytablabol feltoltjuk a visszateresi listat
				while (resultSet.next()) 
				{
					JaratFejlec jarat = new JaratFejlec();
					jarat.setVonatszam(resultSet.getInt("vonatszam"));
					jarat.setTipus(resultSet.getString("tipus"));
					jarat.setMegjegyzes(resultSet.getString("megjegyzes"));
					
					jaratok.add(jarat);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		return jaratok;
	}

	@Override
	public List<JaratVonatszam> getStatistics() throws NotConnectedException {
		checkConnected();
		return null;
	}

	@Override
	public boolean commit() throws NotConnectedException {
		checkConnected();
		try {
			// commit-ot hajtunk vegre majd igazzal terunk vissza
			connection.commit();
			return true;
		} catch (Exception e) {
			// Ha hiba keletkezik hamissal terunk vissza
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public boolean rollback() throws NotConnectedException {
		checkConnected();
		try {
			// rollback-et hajtunk vegre es igazzal terunk vissza
			connection.rollback();
			return true;
		} catch (SQLException e) {
			// Ha hiba keletkezik kozben, hamissal terunk vissza
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public ActionResult insertOrUpdate(Jarat entity, Integer foreignKey)
			throws NotConnectedException, EntityNotFoundException {
		checkConnected();
		
		ActionResult actionResult;
		
		try {
			
			String query;
			
			// bekapcsoljuk az autocommit-ot
			//connection.setAutoCommit(true);
			
			// Megnezzuk letezik e az allomas, ha nem hibaval visszaterunk 
			PreparedStatement checkAllomasPreparedStatement = connection.prepareStatement("SELECT id FROM allomas WHERE id LIKE ?");
			checkAllomasPreparedStatement.setInt(1, foreignKey);
			ResultSet allomasResultSet = checkAllomasPreparedStatement.executeQuery();
			if(!allomasResultSet.next()){
				actionResult = ActionResult.ErrorOccurred;
				return actionResult;
			}
			
			PreparedStatement checkVonatszamPreparedStatement = connection.prepareStatement("SELECT vonatszam FROM jarat WHERE vonatszam LIKE ?");
			checkVonatszamPreparedStatement.setInt(1, entity.getVonatszam());
			
			ResultSet vonatszamResultSet = checkVonatszamPreparedStatement.executeQuery();
			
			if(!vonatszamResultSet.next()){
				
				query = "INSERT INTO jarat (vonatszam, tipus, nap, kezd, vege, megjegyzes) VALUES (?, ?, ?, ?, ?, ?)";
				PreparedStatement insertJaratPreparedStatement = connection.prepareStatement(query);
				
				// Feltoltjuk a preparedStatement parametereit
				insertJaratPreparedStatement.setInt(1, entity.getVonatszam());
				insertJaratPreparedStatement.setString(2, entity.getTipus());
				insertJaratPreparedStatement.setString(3, entity.getNap());
				// Mivel az adatbazisban a datum megadasa nem kotelezo ellenorizzuk hogy null e
				if(entity.getKezd() == null)
					insertJaratPreparedStatement.setDate(4, null);
				else
					insertJaratPreparedStatement.setDate(4, Date.valueOf(entity.getKezd()));
				if(entity.getVege() == null)
					insertJaratPreparedStatement.setDate(5, null);
				else
					insertJaratPreparedStatement.setDate(5, Date.valueOf(entity.getVege()));
				
				insertJaratPreparedStatement.setString(6, entity.getMegjegyzes());
				
				insertJaratPreparedStatement.executeUpdate();
				
				// Megnezzuk melyik a legnagyobb id a megall tablaban, majd ezt megnovelve felhasznaljuk az uj ertek beszurasakor
				Statement megallIdStatement = connection.createStatement();
				ResultSet megallIdResultSet = megallIdStatement.executeQuery("SELECT MAX(id) as value FROM megall");
				megallIdResultSet.next();
				
				int newMegallId = megallIdResultSet.getInt("value");
				newMegallId++;
				
				// Beszurjuk az adott jarat-allomas parost a megall tablaba a generalt id-vel
				query = "INSERT INTO megall (id, vonatszam, allomas_id, erk, ind) VALUES (?, ?, ?, ?, ?)";
				PreparedStatement insertMegallPreparedStatement = connection.prepareStatement(query);
				insertMegallPreparedStatement.setInt(1, newMegallId);
				insertMegallPreparedStatement.setInt(2, entity.getVonatszam());
				insertMegallPreparedStatement.setInt(3, foreignKey);
				insertMegallPreparedStatement.setInt(4, 1015);
				insertMegallPreparedStatement.setInt(5, 1030);
				
				insertMegallPreparedStatement.executeUpdate();
		
				// insert visszateresi ertek
				actionResult = ActionResult.InsertOccurred;
				return actionResult;
			}
			
			else {
				query = "UPDATE jarat SET tipus=?, nap=?, kezd=?, vege=?, megjegyzes=? WHERE vonatszam LIKE ?";
				PreparedStatement updatePreparedStatement = connection.prepareStatement(query);
				
				// Feltoltjuk a preparedStatement parametereit
				updatePreparedStatement.setString(1, entity.getTipus());
				updatePreparedStatement.setString(2, entity.getNap());
				// Mivel az adatbazisban a datum megadasa nem kotelezo ellenorizzuk hogy null e
				if(entity.getKezd() == null)
					updatePreparedStatement.setDate(3, null);
				else
					updatePreparedStatement.setDate(3, Date.valueOf(entity.getKezd()));
				
				if(entity.getVege() == null)
					updatePreparedStatement.setDate(4, null);
				else
					updatePreparedStatement.setDate(4, Date.valueOf(entity.getVege()));
				
				updatePreparedStatement.setString(5, entity.getMegjegyzes());
				updatePreparedStatement.setInt(6, entity.getVonatszam());
				
				updatePreparedStatement.executeUpdate();
				
				// Beallitjuk a visszateresi erteket
				actionResult = ActionResult.UpdateOccurred;
				
				return actionResult;
			}
		}
		catch (SQLException e){
			e.printStackTrace();
			actionResult = ActionResult.ErrorOccurred;
			rollback();
			return actionResult;
		}
	}

	@Override
	public boolean setAutoCommit(boolean value) throws NotConnectedException {
		checkConnected();
		try {
			// az adott ertekre allitjuk az autoCommitot
			connection.setAutoCommit(value);
			
			// Ha ez ezek utan egyezik a kivant ertekkel igazzal terunk vissza
			if(connection.getAutoCommit() == value)
				return true;
			// Hamissal ha nem
			else
				return false;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}

	@Override
	public void disconnect() {
		try {
			rollback();
			connection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (NotConnectedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<Person> sampleQuery() throws NotConnectedException {
		checkConnected();
		List<Person> result = new ArrayList<>();
		try (Statement stmt = connection.createStatement()) {
			try (ResultSet rset = stmt.executeQuery("SELECT nev, szemelyi_szam FROM OKTATAS.SZEMELYEK "
					+ "ORDER BY NEV "
					+ "OFFSET 0 ROWS FETCH NEXT 20 ROWS ONLY")){
				while (rset.next()) {
					Person p = new Person(rset.getString("nev"), rset.getString("szemelyi_szam"));
					result.add(p);
				}
				return result;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
}
