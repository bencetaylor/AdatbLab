Databases Laboratory 5 SOA service demo
=======================================

Usage
-----

   1. Copy `config.sample.json` to `config.json` and fill in your username and password
   2. Install the dependencies (if needed)
   3. Start the service with `python service.py` and enjoy!

Dependencies
------------

   - Requests http://python-requests.org/
   - Flask http://flask.pocoo.org/
   - cxOracle http://cx-oracle.sourceforge.net/
